#!/usr/bin/env python3
"""
download_models.py
------------------
Downloads the pre-trained banana ripeness model weights from the
ParanKafleUTS/AI_Matrix_banana_ripness GitHub repository (via GitHub LFS).

Usage:
    python download_models.py                   # download all three models
    python download_models.py --model efficientnet
    python download_models.py --model mobilenet
    python download_models.py --model resnet
    python download_models.py --force           # re-download even if present

Fixes applied vs original:
    - Use media.githubusercontent.com (GitHub LFS real content, not pointer)
    - Atomic download: write to *.part then rename → no corrupt files on retry
    - Per-chunk read timeout so stalled transfers are detected
    - Optional SHA-256 checksum verification
    - Cleanup of partial file on any failure
"""

from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import sys
import tempfile

import requests

# ---------------------------------------------------------------------------
# GitHub LFS media URL  (raw.githubusercontent.com returns a ~130-byte LFS
# pointer instead of the actual binary weights — use media.githubusercontent.com)
# ---------------------------------------------------------------------------

_LFS_BASE = (
    "https://media.githubusercontent.com/media/"
    "ParanKafleUTS/AI_Matrix_banana_ripness/main/"
)

# ---------------------------------------------------------------------------
# Model registry
# ---------------------------------------------------------------------------
# sha256: set to None to skip verification; fill in once you have the hashes.
# Run:  sha256sum models/*.pth   after a verified first download.
# ---------------------------------------------------------------------------

MODELS: dict[str, dict] = {
    "efficientnet": {
        "filename": "EfficientNetB0_banana_ripeness.pth",
        "url": _LFS_BASE + "EfficientNetB0_banana_ripeness.pth",
        "size_mb": 15.6,
        "sha256": None,  # fill in after first verified download
    },
    "mobilenet": {
        "filename": "MobileNetV3_banana_ripeness.pth",
        "url": _LFS_BASE + "MobileNetV3_banana_ripeness.pth",
        "size_mb": 16.3,
        "sha256": None,
    },
    "resnet": {
        "filename": "ResNet50_banana_ripeness.pth",
        "url": _LFS_BASE + "ResNet50_banana_ripeness.pth",
        "size_mb": 90.1,
        "sha256": None,
    },
}

MODELS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models")

# Timeouts: (connect_s, read_s).  The read timeout applies per chunk so a
# stalled transfer is detected within `read_s` seconds regardless of file size.
_CONNECT_TIMEOUT = 15
_READ_TIMEOUT = 60
_CHUNK_SIZE = 256 * 1024  # 256 KB


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _check_lfs_pointer(path: str) -> bool:
    """Return True if *path* looks like a raw Git LFS pointer (wrong download)."""
    try:
        with open(path, "rb") as fh:
            header = fh.read(512)
        return header.startswith(b"version https://git-lfs.github.com/spec/v1")
    except OSError:
        return False


def download_file(url: str, dest_path: str, size_mb: float) -> None:
    """
    Stream-download *url* to *dest_path* atomically.

    Writes to a *.part* temp file first; renames to dest_path only on
    success.  Removes the temp file on any failure so re-runs start clean.
    """
    part_path = dest_path + ".part"

    print(f"  URL  : {url}")
    print(f"  Dest : {dest_path}  (~{size_mb:.1f} MB)")

    try:
        response = requests.get(
            url,
            stream=True,
            timeout=(_CONNECT_TIMEOUT, _READ_TIMEOUT),
        )
        response.raise_for_status()

        total = int(response.headers.get("content-length", 0))
        downloaded = 0

        with open(part_path, "wb") as fh:
            for chunk in response.iter_content(chunk_size=_CHUNK_SIZE):
                if not chunk:
                    continue
                fh.write(chunk)
                downloaded += len(chunk)
                if total:
                    pct = downloaded / total * 100
                    bar_len = 30
                    filled = int(bar_len * downloaded / total)
                    bar = "█" * filled + "░" * (bar_len - filled)
                    print(f"\r  [{bar}] {pct:5.1f}%", end="", flush=True)

        print()  # end progress line

        # Guard: reject LFS pointer files (wrong URL / repo config)
        if _check_lfs_pointer(part_path):
            os.remove(part_path)
            raise RuntimeError(
                "Downloaded file is a Git LFS pointer, not real weights.\n"
                "  Check the repository URL or use 'git lfs pull' locally."
            )

        # Atomic rename — no half-written file visible to other processes
        shutil.move(part_path, dest_path)

    except Exception:
        # Always clean up partial download so next run doesn't skip it
        if os.path.exists(part_path):
            os.remove(part_path)
        raise


def verify_checksum(path: str, expected: str | None) -> None:
    """If *expected* is set, verify SHA-256 of *path* and raise on mismatch."""
    if expected is None:
        return
    print("  Verifying checksum…", end=" ", flush=True)
    actual = _sha256_of_file(path)
    if actual != expected:
        os.remove(path)
        raise ValueError(
            f"Checksum mismatch!\n"
            f"  expected : {expected}\n"
            f"  got      : {actual}\n"
            f"  File removed — please re-run the script."
        )
    print("OK")


# ---------------------------------------------------------------------------
# Main download logic
# ---------------------------------------------------------------------------


def download_models(names: list[str], *, force: bool = False) -> None:
    os.makedirs(MODELS_DIR, exist_ok=True)

    for name in names:
        info = MODELS[name]
        dest = os.path.join(MODELS_DIR, info["filename"])

        if os.path.exists(dest) and not force:
            print(f"[SKIP] {info['filename']} already exists. Use --force to re-download.")
            continue

        print(f"\n[DOWNLOADING] {info['filename']}")
        try:
            download_file(info["url"], dest, info["size_mb"])
            verify_checksum(dest, info["sha256"])
            print(f"[OK] Saved → {dest}\n")
        except requests.HTTPError as exc:
            print(f"\n[ERROR] HTTP {exc.response.status_code} for {name}: {exc}", file=sys.stderr)
            sys.exit(1)
        except (requests.ConnectionError, requests.Timeout) as exc:
            print(f"\n[ERROR] Network error for {name}: {exc}", file=sys.stderr)
            sys.exit(1)
        except (OSError, RuntimeError, ValueError) as exc:
            print(f"\n[ERROR] {exc}", file=sys.stderr)
            sys.exit(1)

    print(f"\nAll requested models are ready in: {MODELS_DIR}")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Download banana-ripeness model weights from GitHub LFS.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--model",
        choices=list(MODELS.keys()),
        default=None,
        help="Which model to download (default: all).",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Re-download even if the file already exists.",
    )
    args = parser.parse_args()

    names = [args.model] if args.model else list(MODELS.keys())
    download_models(names, force=args.force)


if __name__ == "__main__":
    main()
